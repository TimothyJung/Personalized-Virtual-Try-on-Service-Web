import Navigation from './Navigationbar/Nav'
import Footer from './Footer'

function RecommendPage() {
  return (
    <div>
      <Navigation></Navigation>
      <Footer></Footer>
    </div>
  )
}
export default RecommendPage
