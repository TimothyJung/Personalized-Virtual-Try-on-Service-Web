export const API_URL = 'http://localhost:3000'
// 배포 시, 위 코드 주석처리 후 다음 코드로 변경
// export const API_URL = 'http://www.model-fit.kro.kr'
