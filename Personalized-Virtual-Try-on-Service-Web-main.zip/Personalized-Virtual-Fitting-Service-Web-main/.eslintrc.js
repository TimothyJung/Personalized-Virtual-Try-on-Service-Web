module.exports = {
  extends: ['airbnb-base', 'plugin:node/recommended', 'prettier'],
  plugins: ['react', '@typescript-eslint', 'mongodb'],
}
